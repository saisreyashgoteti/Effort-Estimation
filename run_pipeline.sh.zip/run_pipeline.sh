#!/bin/bash

echo "=========================================================="
echo "   Effort Estimation Project - End-to-End Local Run"
echo "=========================================================="

# 1. Cleaning
echo "[1/4] Cleaning previous mock data..."
rm -rf data_collection/raw_data/*.json
rm -rf analysis/processed_metrics/*.json
rm -rf external_data/normalized_benchmarks.json
echo "      Cleaned."

# 2. Mock Data Generation
echo "[2/4] Generating Mock Repository Data (Simulating Octokit)..."
python3 data_collection/generate_mock_data.py
if [ $? -ne 0 ]; then echo "Stats: Generation failed"; exit 1; fi

# 3. Analysis Processing
echo "[3/4] Running Analysis Pipeline (Gemma 3 Logic)..."
# Ensure the script uses the correct relative paths
cd analysis
python3 process_data.py
cd ..
if [ $? -ne 0 ]; then echo "Status: Analysis failed"; exit 1; fi

# 4. External Data
echo "[3.5/4] Importing Manual Benchmarks (Research Papers)..."
python3 external_data/import_external.py
if [ $? -ne 0 ]; then echo "Status: Benchmark import failed"; exit 1; fi

# 5. Model Training
echo "[4/4] Training Model (Vertex AI Simulation)..."
python3 model_training/src/task.py --local-data-dir analysis/processed_metrics

echo "=========================================================="
echo "   Pipeline Completed Successfully."
echo "=========================================================="
