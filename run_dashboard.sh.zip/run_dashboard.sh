#!/bin/bash

echo "=========================================================="
echo "   Effort Estimation Project - Dashboard Launcher"
echo "=========================================================="

echo "Starting Flask Server..."
python3 app.py
